package com.example;

public class App {

    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println(" Java Application Started!");
        System.out.println("================================");

        System.out.println("Java Version: "
                + System.getProperty("java.version"));

        System.out.println("Java Vendor: "
                + System.getProperty("java.vendor"));

        System.out.println("The found of this company is Kulandaiyan S")

        System.out.println("Application: Docker + Azul Zulu");

    }
}