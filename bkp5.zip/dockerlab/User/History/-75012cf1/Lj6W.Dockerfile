FROM ubuntu.jammy
RUN "apt update -y"
RUN "aot install mysql-client -y"
RUN [ "mkdir /myapp" ]