#create java based app azul zulu
java-docker-app/
|── Dockerfile
├── pom.xml
└── src/
    └── main/
        └── java/
            └── com/
                └── example/
                    └── App.java
####
package com.example;

public class App {

    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println(" Java Application Started!");
        System.out.println("================================");

        System.out.println("Java Version: "
                + System.getProperty("java.version"));

        System.out.println("Java Vendor: "
                + System.getProperty("java.vendor"));

        System.out.println("Application: Docker + Azul Zulu");

    }
}

pom.xml
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         https://maven.apache.org/xsd/maven-4.0.0.xsd">

    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example</groupId>
    <artifactId>java-docker-app</artifactId>
    <version>1.0</version>

    <properties>
        <maven.compiler.release>21</maven.compiler.release>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

</project>