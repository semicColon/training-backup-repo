# ==========================================
# Stage 1: Build Java Application
# ==========================================

FROM azul-zulu:21 AS builder
WORKDIR /app
# Copy Maven configuration
COPY pom.xml .
# Copy application source
COPY src ./src
# Compile Java application
RUN javac -d target/classes src/main/java/com/example/App.java
# Package application into JAR
RUN jar --create --file target/java-docker-app.jar --main-class com.example.App -C target/classes .


# ==========================================
# Stage 2: Runtime Environment
# ==========================================
FROM azul-zulu:21-jre
WORKDIR /app

# Copy JAR from builder stage
COPY --from=builder /app/target/java-docker-app.jar app.jar

# Run application
ENTRYPOINT ["java", "-jar", "app.jar"]
